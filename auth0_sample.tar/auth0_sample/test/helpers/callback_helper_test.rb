require 'test_helper'

class CallbackHelperTest < ActionView::TestCase
end
